# Project Tugas Akhir
## Pembuatan sistem Named Entity Recognition untuk dokumen putusan pengadilan wilayah madura dengan Arstitektur Bi-LSTM menggunakan optimizer:
- SGD
- Adam
- Rmsprop

### Link Sistem : http://wahyuarilsptr.pythonanywhere.com
